
package progpoe2024;

import java.util.Scanner;

public class PROGPOE2024 {
   
   
    public static void main(String[] args) {
         Scanner scanner = new Scanner(System.in);
        //create variables to receive user input
        System.out.println("Welcome to Registration and Login System");
        System.out.println("----------------------------------------");
        
        System.out.println("Enter your username: ");
        String username = scanner.nextLine();
        
        System.out.println("Enter your password: ");
        String password = scanner.nextLine();
        
        System.out.println("Enter your first name: ");
        String firstName = scanner.nextLine();
        
        System.out.println("Enter your last name: ");
        String LastName = scanner.nextLine();
        
        Login login = new Login(); 
        
        String registrationMessage = login.registerUser(username, password);
        System.out.println(registrationMessage);
        
        if (registrationMessage.equals("User registered successfully.")) {
            System.out.println("Enter your username to login: ");
            String enteredUsername = scanner.nextLine();
            
            System.out.println("Enter your password to login: ");
            String enteredPassword = scanner.nextLine();
            
            boolean isSuccessful = login.loginUser(username, enteredUsername, enteredPassword, password);
            System.out.println(login.returnLoginStatus(isSuccessful, firstName, LastName));
        }
        
        scanner.close();
    
    }
    
}
